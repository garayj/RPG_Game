#include "Space.hpp"
Space::Space(){}

Space::~Space(){}