/**************************************************************************************************
** Author: Jose Garay
** Date: 11/26/2018
** Description: Interface for the Team class. The Team class simulates a team of characters that 
may be either monsters or heroes. Teams have a location, size, Characters, an inventory, and a 
boolean data member to check whether the Team is alive or not.
**************************************************************************************************/
#include "Team.hpp"
#include "Menu.hpp"
#include "Potion.hpp"
#include "Equipment.hpp"
#include <iostream>
using std::cout;
using std::endl;

Team::Team(int size){
	setInventorySize(10);
	setIsTeamAlive(true);
	setTeamSize(size);
	setLocation(nullptr);

	setInventory(new vector<Item*>());

	characters = new Character*[getTeamSize()];
	// inventory = new Item*[getInventory()->size()];

	//Set every space in the inventory to null for an empty inventory.
	// for(int n = 0; n < getInventory()->size(); n++){
	// 	getInventory()->push_back(nullptr);
	// }
}

Team::~Team(){
	//Delete all the Characters in the Team.
	if(getCharacters() != nullptr){
		for(int n = 0; n < getTeamSize(); n++){
			if(getCharacters()[n] != nullptr){
				delete getCharacters()[n];
			}
		}
		delete [] getCharacters();
	}	
	//Delete anything left in the inventory.
	while(!getInventory()->empty()){
		delete getInventory()->at(getInventory()->size() - 1);
		getInventory()->pop_back();
	}
	delete getInventory();

}

bool Team::teamAliveStatus(){
	for(int n = 0; n < getTeamSize(); n++){
		if(getCharacters()[n]->getIsAlive()){
			return true;
		}
	}
	setIsTeamAlive(false);
	return false;
}

void Team::printCharacters(){
	int place = 1; 
	//
	for(int n = 0; n < getTeamSize(); n++){
		cout << place << ". " << getCharacters()[n]->getName() << " the "<< getCharacters()[n]->getCharacterClassString() << endl;
		place++;
	}
	cout << "\n";
}

void Team::addItemToInventory(Item *newItem){
	// bool itemNotPlaced = true;
	// int n = 0;
	// while(itemNotPlaced && n < getInventory()->size()){
	// 	if(getInventory()->at(n) == nullptr){
	// 		getInventory()->at(n) = newItem;
	// 		itemNotPlaced = false;
	// 	}
	// 	n++;
	// }

	getInventory()->push_back(newItem);
}

bool Team::isInventoryFull(){
	for(int n = 0; n < getInventory()->size();n++){
		if(getInventory()->at(n) != nullptr){
			return false;
		}
	}
	return true;
}

void Team::removeItemFromInventory(int n){
	delete getInventory()->at(n);
	getInventory()->erase(getInventory()->begin() + n);
}

void Team::printInventory(){
	int count = 1;
	for(int n = 0; n < getInventory()->size();n++){
		if(getInventory()->at(n) != nullptr){
			cout << count << ": " << getInventory()->at(n)->getItemName() << endl;
			count++;
		}
	}
	cout << "\n\n";
}

void Team::printConsumableInventory(){
	int count = 1;
	for(int n = 0; n < getInventory()->size();n++){
		if(getInventory()->at(n) != nullptr && getInventory()->at(n)->getItemType() == POTION){
			cout << count << ": " << getInventory()->at(n)->getItemName() << endl;
			count++;
		}
	}
}

void Team::magicBag(int itemIndex){
	Menu menu;
	int characterIndex;
	if(getInventory()->at(itemIndex - 1)->getItemType() == POTION){
		Menu menu;
		cout << "Select the item you would like to use or select 0 to go back.\n";
		printCharacters();				

		characterIndex = menu.checkInputInt("Oops please select an item in the inventory\n", 1, getTeamSize());

		dynamic_cast<Potion*>(getInventory()->at(itemIndex - 1))->usePotion(getCharacters()[characterIndex - 1]);
		delete getInventory()->at(itemIndex - 1);

		getInventory()->erase(getInventory()->begin() + itemIndex - 1);

	}
	else{
		cout << "Who would you like to hold this?\n";
		printCharacters();				

		characterIndex = menu.checkInputInt("Ooops! Please select a hero in the menu\n", 1, getTeamSize());

		if(getCharacters()[characterIndex -1]->getSlot1() == nullptr){
			getCharacters()[characterIndex - 1]->setSlot1(dynamic_cast<Equipment*>(getInventory()->at(itemIndex - 1)));
			cout << getCharacters()[characterIndex - 1]->getName() << " is now holding " << getCharacters()[characterIndex - 1]->getSlot1()->getItemName() << " in slot 1." << std::endl;
			getInventory()->erase(getInventory()->begin() + itemIndex - 1);
		}
		else if(getCharacters()[characterIndex - 1]->getSlot2() == nullptr){
			getCharacters()[characterIndex - 1]->setSlot2(dynamic_cast<Equipment*>(getInventory()->at(itemIndex - 1)));
			cout << getCharacters()[characterIndex - 1]->getName() << " is now holding " << getCharacters()[characterIndex - 1]->getSlot2()->getItemName() << " in slot 2." << std::endl;
			getInventory()->erase(getInventory()->begin() + itemIndex - 1);
		}

	}
}


