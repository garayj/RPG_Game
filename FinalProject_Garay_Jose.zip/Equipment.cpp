#include "Equipment.hpp"	
Equipment::~Equipment(){}
Equipment::Equipment(){}