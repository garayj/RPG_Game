#include "SwampEvent.hpp"
#include <iostream>

SwampEvent::SwampEvent(Team*){
	//Things that can happen is swamp are fights and that's it. no camping.
	std::cout << "This is the SwampEvent placeholder.\n\n";

}