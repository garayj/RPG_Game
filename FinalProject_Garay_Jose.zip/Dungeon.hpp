#ifndef DUNGEON_HPP
#define DUNGEON_HPP
#include "Space.hpp"
class Dungeon:public Space
{
public:
	Dungeon();
	~Dungeon();
	
};
#endif