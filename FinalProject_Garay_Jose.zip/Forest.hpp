#ifndef FOREST_HPP
#define FOREST_HPP
#include "Space.hpp"
class Forest:public Space
{
public:
	Forest();
	~Forest();
	
};
#endif