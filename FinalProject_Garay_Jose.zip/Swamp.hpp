#ifndef SWAMP_HPP
#define SWAMP_HPP
#include "Space.hpp"
class Swamp:public Space
{
public:
	Swamp();
	~Swamp();
	
};
#endif