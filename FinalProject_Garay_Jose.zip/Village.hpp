#ifndef VILLAGE_HPP
#define VILLAGE_HPP 
#include "Space.hpp"
class Village:public Space
{
public:
	Village();
	~Village();
	
};
#endif