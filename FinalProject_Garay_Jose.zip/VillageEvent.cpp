#include "VillageEvent.hpp"
#include <iostream>

VillageEvent::VillageEvent(Team *heroes){
	//menu options
	std::cout << "Placeholder for the VillageEvent\n\n";
}