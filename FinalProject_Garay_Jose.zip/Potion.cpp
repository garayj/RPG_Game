#include "Potion.hpp"

Potion::Potion(){}

Potion::~Potion(){}