#ifndef GREATER_SWORD_HPP
#define GREATER_SWORD_HPP 
#include "Equipment.hpp"
class GreaterSword : public Equipment
{
public:
	GreaterSword();
	~GreaterSword();
};
#endif