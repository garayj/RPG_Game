#ifndef GRASS_HPP
#define GRASS_HPP 
#include "Space.hpp"
class Grass:public Space
{
public:
	Grass();
	~Grass();
	
};
#endif