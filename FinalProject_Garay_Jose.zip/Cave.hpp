#ifndef CAVE_HPP
#define CAVE_HPP 
#include "Space.hpp"
class Cave:public Space
{
public:
	Cave();
	~Cave();
	
};
#endif