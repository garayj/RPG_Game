#include <iostream>
#include "ForestEvent.hpp"

ForestEvent::ForestEvent(Team *heroes){
	//Camp in forest, get attacked in forest, forage in forest.
	std::cout << "This is the placeholder for the ForestEvent.\n\n";
}